﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Xml.Serialization;
using ProtoBuf;

namespace _9_1
{
    [ProtoContract]
    public class Info
    {
        private string name;
        private string society;
        private int firstResult;
        private int secondResult;
        private bool disqualified;
        [ProtoMember(1)]
        public string Name 
        {
            get { return name; }
            set { name = value ?? string.Empty; }
        }
        [ProtoMember(2)]
        public string Society 
        {
            get { return society; }
            set { society = value ?? string.Empty; }
        }
        [ProtoMember(3)]
        public int FirstResult 
        {
            get { return firstResult; }
            set { firstResult = value; }
        }
        [ProtoMember(4)]
        public int SecondResult 
        {
            get { return secondResult; }
            set { secondResult = value; }
        }
        [ProtoMember(5)]
        public bool Disqualified 
        {
            get { return disqualified; }
            set { disqualified = value; }
        }
        public int Summ { get { return FirstResult + SecondResult; } } 
        public Info()
        {
        }
        public Info(string name, string society, int firstResult, int secondResult) 
        {
            Name = name;
            Society = society;
            FirstResult = firstResult;
            SecondResult = secondResult;
            Disqualified = false;
        }
        public void Disqual() { Disqualified = true; }  
        public void Print() { if (Disqualified == false) { Console.WriteLine($"{Name}\t{Society}\t{Summ}"); } }
    }
    public class Program
    {  
        static void Main(string[] args)
        {
            Info[] info = new Info[5];

            info[0] = new Info("Марк", "ББИ-23-4", 200, 300);   
            info[1] = new Info("Валентин", "ББИ-23-3", 100, 200);
            info[2] = new Info("Дмитрий", "ББИ-23-2", 155, 185);
            info[3] = new Info("Юрий", "ББИ-23-1", 101, 204);
            info[4] = new Info("Денис", "ББИ-23-4", 130, 190);

            info[2].Disqual(); 

            for (int i = 0; i < info.Length - 1; i++)   
            {
                for (int j = i + 1; j < info.Length; j++)
                {
                    if (info[i].Summ < info[j].Summ)
                    {
                        Info pomoch = info[j];
                        info[j] = info[i];
                        info[i] = pomoch;
                    }
                }
            }

            SerializeClass[] serializers = new SerializeClass[3]
            {
                new JsonCode(),
                new XmlCode(), 
                new BinaryCode()
            };

            string path = Environment.CurrentDirectory;
            path = Path.Combine(path, "1");
            if (!Directory.Exists(path))    
            {
                Directory.CreateDirectory(path);
            }
            string[] files = new string[3]
            {
                "1.json",
                "1.xml",
                "1.bin"
            };

            for (int i = 0; i < serializers.Length; i++)
                serializers[i].Write(info, Path.Combine(path, files[i]));

            for (int i = 0; i < serializers.Length; i++)
            {   
                Console.WriteLine($"From {files[i]}");
                Console.WriteLine("Место\tИмя\tОбщество\tСумма результатов"); 
                info = serializers[i].Read<Info[]>(Path.Combine(path, files[i]));
                int a = 0;
                for (int j = 0; j < info.Length; j++) 
                {
                    if (info[j].Disqualified == false) 
                    {
                        Console.Write($"{a + 1}\t");
                        a += 1;
                    }
                    info[j].Print();
                }
                Console.WriteLine();
            }
        }
    }
}


namespace _9_2
{
    [JsonDerivedType(typeof(SkiJump120m), typeDiscriminator: "120")]
    [JsonDerivedType(typeof(SkiJump180m), typeDiscriminator: "180")]
    [XmlInclude(typeof(SkiJump120m))]
    [XmlInclude(typeof(SkiJump180m))]
    [ProtoInclude(6, typeof(SkiJump120m))]
    [ProtoInclude(7, typeof(SkiJump180m))]
    [ProtoContract]
    public abstract class Competition
    {
        protected string disciplineName;
        protected string lastName;
        protected double[] styleScores;
        protected double jumpDistance;
        protected double totalScore;
        [ProtoMember(1)]
        public string DisciplineName
        {
            get { return disciplineName; }
            set { disciplineName = value ?? string.Empty; }
        }
        [ProtoMember(2)]
        public string LastName
        {
            get { return lastName; }
            set { lastName = value ?? string.Empty; }
        }
        [ProtoMember(3)]
        public double[] StyleScores
        {
            get { return styleScores; }
            set { styleScores = value; }
        }
        [ProtoMember(4)]
        public double JumpDistance
        {
            get { return jumpDistance; }
            set { jumpDistance = value; }
        }
        [ProtoMember(5)]
        public double TotalScore
        {
            get { return totalScore; }
            set { totalScore = value; }
        }
        protected double BaseDistance { get; set; } = 120.0;
        protected double BaseScore { get; set; } = 60.0;
        protected double ScorePerMeter { get; set; } = 2.0;
        protected double PenaltyPerMeter { get; set; } = -2.0;

        public Competition(string lastName, double[] styleScores, double jumpDistance)
        {
            this.lastName = lastName;
            this.styleScores = styleScores;
            this.jumpDistance = jumpDistance;
            this.totalScore = 0;
            CalculateTotalScore();
        }
        public Competition() 
        {
        }

        protected void CalculateTotalScore()
        {
            double sum = 0;
            for (int k = 1; k < styleScores.Length - 1; k++)
            {
                sum += styleScores[k];
            }
            double distanceDifference = jumpDistance - BaseDistance;
            double distanceScore = distanceDifference > 0
                ? BaseScore + distanceDifference * ScorePerMeter
                : BaseScore + distanceDifference * PenaltyPerMeter;

            totalScore = sum + distanceScore;
        }
    }
    [ProtoContract]
    public class SkiJump120m : Competition
    {
        public SkiJump120m(string lastName, double[] styleScores, double jumpDistance)
            : base(lastName, styleScores, jumpDistance)
        {
            DisciplineName = "120м";
        }
        public SkiJump120m() 
        {
        }
    }
    [ProtoContract]
    public class SkiJump180m : Competition
    {
        public SkiJump180m(string lastName, double[] styleScores, double jumpDistance)
            : base(lastName, styleScores, jumpDistance)
        {
            DisciplineName = "180м";
        }
        public SkiJump180m()
        {
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Competition[] competitions = new Competition[5];
            competitions[0] = new SkiJump120m("Трамп", new double[] { 18.5, 17.5, 19.0, 20.0, 18.0 }, 122.0);
            competitions[1] = new SkiJump120m("Обама", new double[] { 19.0, 18.0, 17.0, 16.5, 18.5 }, 118.0);
            competitions[2] = new SkiJump180m("Путин", new double[] { 20.0, 19.5, 19.0, 18.5, 20.0 }, 125.0);
            competitions[3] = new SkiJump120m("Дзюба", new double[] { 17.5, 17.0, 18.5, 19.0, 18.0 }, 121.5);
            competitions[4] = new SkiJump180m("Глушаков", new double[] { 19.5, 20.0, 19.0, 18.5, 19.5 }, 123.5);

            Array.Sort(competitions, (a, b) => b.TotalScore.CompareTo(a.TotalScore));

            Console.WriteLine($"Соревнования по прыжкам на лыжах ({competitions[0].DisciplineName})");
            Console.WriteLine("Результаты:");
            for (int i = 0; i < competitions.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {competitions[i].LastName}: {competitions[i].TotalScore} очков");
            }

            SerializeClass[] serializers = new SerializeClass[3]
            {
                new JsonCode(),
                new XmlCode(), 
                new BinaryCode()
            };

            string path = Environment.CurrentDirectory;
            path = Path.Combine(path, "2");
            if (!Directory.Exists(path))    
            {
                Directory.CreateDirectory(path);
            }
            string[] files = new string[3]
            {
                "2.json",
                "2.xml",
                "2.bin"
            };

            for (int i = 0; i < serializers.Length; i++)
                serializers[i].Write(competitions, Path.Combine(path, files[i]));

            for (int i = 0; i < serializers.Length; i++)
            {   
                Console.WriteLine($"From {files[i]}");
                Console.WriteLine($"Соревнования по прыжкам на лыжах ({competitions[0].DisciplineName})");
                Console.WriteLine("Результаты:");
                competitions = serializers[i].Read<Competition[]>(Path.Combine(path, files[i]));
                for (int j = 0; j < competitions.Length; j++)
            {
                Console.WriteLine($"{j + 1}. {competitions[j].LastName}: {competitions[j].TotalScore} очков");
            }
                Console.WriteLine();
            }
        }
    }
}

namespace _9_3
{
    [JsonDerivedType(typeof(WomanTeam), typeDiscriminator: "woman")]
    [JsonDerivedType(typeof(ManTeam), typeDiscriminator: "man")]
    [XmlInclude(typeof(WomanTeam))]
    [XmlInclude(typeof(ManTeam))]
    [ProtoInclude(3, typeof(WomanTeam))]
    [ProtoInclude(4, typeof(ManTeam))]
    [ProtoContract]
    public abstract class Team
    {
        protected string name;
        protected int score;
        [ProtoMember(1)]
        public string Name
        { 
            get { return name; }
            set { name = value ?? string.Empty; }
        }
        [ProtoMember(2)]
        public int Score
        { 
            get { return score; }
            set { score = value; }
        }
        public Team(string name, int score)
        {
            Name = name;
            Score = score;
        }
        public Team() 
        {
        }
        public abstract void Print();
    }

    [ProtoContract]
    public class WomanTeam : Team
    {
        public WomanTeam(string name, int score) : base(name, score) { }
        public WomanTeam() : base() { }
        public override void Print()
        {
            Console.WriteLine($"{Name} (Woman): {Score}");
        }
    }

    [ProtoContract]
    public class ManTeam : Team
    {
        public ManTeam(string name, int score) : base(name, score) { }
        public ManTeam() : base() { }
        public override void Print()
        {
            Console.WriteLine($"{Name} (Man): {Score}");
        }
    }

    class Program
    {
        static void PrintResults(Team[] group) 
        {
            foreach (var participant in group)
            {
                participant.Print();
            }
        }
        static int TotalScore(Team[] group) 
        {
            int total = 0;
            foreach (var participant in group)
            {
                total += participant.Score;
            }
            return total;
        }
        static Team[] FindWinner(Team[] group1, Team[] group2)  
        {
            if (TotalScore(group1) > TotalScore(group2)) { return group1; }
            else { return group2; };
        }
        static void Sortirovka(Team[] info)
        {
            for (int i = 0; i < info.Length - 1; i++)  
            {
                for (int j = i + 1; j < info.Length; j++)
                {
                    if (info[j].Score > info[i].Score)
                    {
                        Team pomoch = info[j];
                        info[j] = info[i];
                        info[i] = pomoch;
                    }
                }
            }
        }

        static void Main(string[] args)
        {
            WomanTeam[] groupWoman = new WomanTeam[5] { new WomanTeam("Желонкин", 1), new WomanTeam("Подземельный", 2), new WomanTeam("Трамп", 3), new WomanTeam("Обама", 4), new WomanTeam("Пушкин", 5) };
            ManTeam[] groupMan = new ManTeam[5] { new ManTeam("Путин", 9), new ManTeam("Дураков", 8), new ManTeam("Лисицин", 7), new ManTeam("Андреев", 6), new ManTeam("Жопкин", 5) };

            Console.WriteLine("\nРезультаты женской команды:"); 
            Sortirovka(groupWoman);
            PrintResults(groupWoman);

            Console.WriteLine("\nРезультаты мужской команды:"); 
            Sortirovka(groupMan);
            PrintResults(groupMan);

            Console.WriteLine($"\nРезультаты команды победителей: "); 
            PrintResults(FindWinner(groupWoman, groupMan));


            SerializeClass[] serializers = new SerializeClass[3]
            {
                new JsonCode(),
                new XmlCode(), 
                new BinaryCode()
            };

            string path = Environment.CurrentDirectory;
            path = Path.Combine(path, "3");
            if (!Directory.Exists(path))    
            {
                Directory.CreateDirectory(path);
            }
            string[] fileswoman = new string[3]
            {
                "2w.json",
                "2w.xml",
                "2w.bin"
            };

            for (int i = 0; i < serializers.Length; i++)
                serializers[i].Write(groupWoman, Path.Combine(path, fileswoman[i]));

            string[] filesman = new string[3]
            {
                "2m.json",
                "2m.xml",
                "2m.bin"
            };

            for (int i = 0; i < serializers.Length; i++)
                serializers[i].Write(groupMan, Path.Combine(path, filesman[i]));

            for (int i = 0; i < serializers.Length; i++)
            {   
                Console.WriteLine($"From {filesman[i]} and {fileswoman[i]}");
                groupWoman = serializers[i].Read<WomanTeam[]>(Path.Combine(path, fileswoman[i]));
                groupMan = serializers[i].Read<ManTeam[]>(Path.Combine(path, filesman[i]));
                Console.WriteLine("\nРезультаты женской команды:"); 
                Sortirovka(groupWoman);
                PrintResults(groupWoman);
                Console.WriteLine("\nРезультаты мужской команды:"); 
                Sortirovka(groupMan);
                PrintResults(groupMan);
                Console.WriteLine($"\nРезультаты команды победителей: "); 
                PrintResults(FindWinner(groupWoman, groupMan));
                Console.WriteLine();
            }
        }
    }
}



